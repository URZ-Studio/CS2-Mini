@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 build.py %*
) else (
  python build.py %*
)
if errorlevel 1 (
  echo Build failed. Check the messages above.
  pause
  exit /b 1
)
echo Build complete. Read README-KO.txt before importing.
pause
