"""MiniCraft II: generate sparse SC2 catalog overrides, no game executable changes."""
import argparse, copy, io, json, re, sys, urllib.request, zipfile
from collections import defaultdict
from decimal import Decimal as D, ROUND_HALF_UP
from pathlib import Path
import xml.etree.ElementTree as E

ROOT=Path(__file__).resolve().parent
LAYERS='core liberty libertymulti swarm swarmmulti void voidmulti'.split()
FILES='UnitData ActorData EffectData AbilData UpgradeData BehaviorData FootprintData GameData'.split()
URL='https://codeload.github.com/SC2Mapster/SC2GameData/zip/refs/heads/master'
UNITS=set('SCV Marine Marauder Reaper Ghost Hellion HellionTank WidowMine WidowMineBurrowed SiegeTank SiegeTankSieged Cyclone Thor ThorAP VikingFighter VikingAssault Medivac Liberator LiberatorAG Raven Banshee Battlecruiser MULE PointDefenseDrone AutoTurret Drone DroneBurrowed Zergling ZerglingBurrowed Baneling BanelingBurrowed BanelingCocoon Roach RoachBurrowed Ravager RavagerCocoon RavagerBurrowed Hydralisk HydraliskBurrowed LurkerMP LurkerMPBurrowed LurkerMPEgg Queen QueenBurrowed Infestor InfestorBurrowed SwarmHostMP SwarmHostBurrowedMP LocustMP LocustMPFlying Ultralisk UltraliskBurrowed Mutalisk Corruptor BroodLord BroodLordCocoon Viper Overlord OverlordTransport TransportOverlord Overseer OverseerSiegeMode OverseerCocoon OverlordTransportCocoon Larva Egg Broodling Changeling ChangelingMarine ChangelingMarineShield ChangelingZealot ChangelingZergling ChangelingZerglingWings Probe Zealot Stalker Sentry Adept AdeptPhaseShift HighTemplar DarkTemplar Archon Immortal Colossus Disruptor DisruptorPhased Observer ObserverSiegeMode WarpPrism WarpPrismPhasing Phoenix VoidRay Oracle Tempest Carrier Interceptor Mothership'.split())
MAIN=set('CommandCenter OrbitalCommand PlanetaryFortress Hatchery Lair Hive Nexus'.split())
MED=set('EngineeringBay Armory GhostAcademy FusionCore Bunker SpawningPool RoachWarren BanelingNest HydraliskDen LurkerDenMP InfestationPit Spire GreaterSpire UltraliskCavern Gateway WarpGate CyberneticsCore Forge TwilightCouncil TemplarArchive DarkShrine RoboticsFacility RoboticsBay Stargate FleetBeacon'.split())
SMALL=set('SupplyDepot SupplyDepotLowered MissileTurret SensorTower Pylon PylonOvercharged PhotonCannon ShieldBattery SpineCrawler SporeCrawler'.split())
SPECIAL=set('Barracks Factory Starport BarracksFlying FactoryFlying StarportFlying BarracksTechLab FactoryTechLab StarportTechLab BarracksReactor FactoryReactor StarportReactor TechLab Reactor CommandCenterFlying OrbitalCommandFlying Refinery RefineryRich Extractor ExtractorRich Assimilator AssimilatorRich SpineCrawlerUprooted SporeCrawlerUprooted CreepTumor CreepTumorBurrowed CreepTumorQueen Nuke'.split())
UNITS |= MAIN|MED|SMALL|SPECIAL
VITAL=set('LifeMax LifeStart ShieldsMax ShieldsStart LifeArmor ShieldArmor ShieldsArmor LifeRegenRate ShieldRegenRate ShieldsRegenRate'.split())
RADIUS=set('Radius InnerRadius SeparationRadius'.split())
ECON={'Minerals','Vespene'}

def fmt(x): return format(x.normalize(),'f') if x else '0'
def mul(s,f,integer=False):
    try: v=D(s)*D(str(f))
    except Exception: return None
    if not v.is_finite(): return None
    if integer: v=v.quantize(D('1'),rounding=ROUND_HALF_UP)
    return fmt(v)
def put(node,tag,value,index=None):
    a={'value':str(value)}
    if index is not None: a['index']=str(index)
    E.SubElement(node,tag,a)
def getval(n): return n.get('value') if n is not None else None

def fetch_catalogs(source):
    # Accept a local snapshot zip, or extracted repository root; otherwise download on the user's PC.
    if source is None:
        source=ROOT/'SC2GameData.zip'
        if not source.exists():
            print('Downloading public SC2Mapster game-data snapshot...',flush=True)
            req=urllib.request.Request(URL,headers={'User-Agent':'MiniCraftII/0.1'})
            tmp=source.with_suffix('.part')
            try:
                with urllib.request.urlopen(req,timeout=120) as inp, tmp.open('wb') as out:
                    import shutil; shutil.copyfileobj(inp,out)
                tmp.replace(source)
            finally:
                if tmp.exists(): tmp.unlink()
    source=Path(source)
    if source.is_dir():
        paths={str(p.relative_to(source)).replace('\\','/').lower():p for p in source.rglob('*.xml')}
        read=lambda p: paths[p].read_bytes()
    else:
        z=zipfile.ZipFile(source)
        paths={p.lower():p for p in z.namelist()}
        read=lambda p:z.read(paths[p])
    data={f:defaultdict(list) for f in FILES}; loaded=[]
    for layer in LAYERS:
        count=0
        for f in FILES:
            suffix=f'mods/{layer}.sc2mod/base.sc2data/gamedata/{f.lower()}.xml'
            candidates=[p for p in paths if p.endswith('/'+suffix) or p==suffix]
            if not candidates: continue
            doc=E.fromstring(read(candidates[0])); count+=1
            for n in doc:
                if n.get('id') and n.tag.startswith('C'): data[f][n.get('id')].append(n)
        if count: loaded.append(layer)
    if not {'liberty','swarm','void','voidmulti'}.issubset(loaded): raise RuntimeError('Missing required LotV data layers: '+str(loaded))
    return data,loaded

def flat(records):
    # Layer direct scalar/indexed overrides. No guess at inherited array ordering.
    out={}
    for n in records:
        for c in n:
            if 'value' in c.attrib and (len(c)==0):
                key=(c.tag,c.get('index'))
                if c.get('removed')=='1': out.pop(key,None)
                else: out[key]=c.get('value')
    return out

def resolved(catalog,id,seen=None):
    seen=set() if seen is None else seen
    if id in seen or id not in catalog: return {}
    seen=seen|{id}; records=catalog[id]; parent=None
    for n in records:
        if 'parent' in n.attrib: parent=n.get('parent')
    out=resolved(catalog,parent,seen) if parent else {}
    out.update(flat(records)); return out

def patch(data,out):
    docs={f:E.Element('Catalog') for f in FILES if f!='FootprintData'}
    warnings=[]; counts={}; units=data['UnitData']; selected=UNITS & set(units)
    missing=sorted(UNITS-selected); warnings.append('Missing optional/variant unit IDs: '+', '.join(missing))
    # Only known standard melee unit types; map doodads and resources untouched.
    for id in sorted(selected):
        n=E.SubElement(docs['UnitData'],'CUnit',{'id':id}); fields=resolved(units,id)
        for (k,i),v in fields.items():
            factor=None; integer=False
            if k in VITAL: factor=.1
            elif k in RADIUS: factor=.5
            elif k=='Food':
                # Negative = consumption; positive = supply provision (unchanged).
                if D(v)<0: factor=.5
            elif k=='CostResource' and i in ECON: factor=.5; integer=True
            if factor is not None:
                val=mul(v,factor,integer)
                if val is not None: put(n,k,val,i)
        # Preserve specialised attachment, refinery and creep-tumor footprints until tested.
        size=3 if id in MAIN else 2 if id in MED else 1 if id in SMALL else None
        if size:
            for k in ('Footprint','PlacementFootprint'):
                old=fields.get((k,None),'')
                if not old: continue
                m=re.match(r'^Footprint\d+x\d+(.*)$',old)
                if not m: warnings.append(f'{id}.{k}: special footprint {old} retained'); continue
                tail=m.group(1); target=f'Footprint{size}x{size}{tail}'
                if target not in data['FootprintData']:
                    # Preserve creep and special placement rules, never silently discard them.
                    warnings.append(f'{id}.{k}: no matching {target}; retained {old}'); continue
                put(n,k,target)
        if not len(n): docs['UnitData'].remove(n)
    # Actor creation uses relative SetScale, retaining original model scale.
    for id,rs in sorted(data['ActorData'].items()):
        if rs[-1].tag!='CActorUnit': continue
        name=next((r.get('unitName') for r in reversed(rs) if r.get('unitName')),id)
        if name not in selected: continue
        n=E.SubElement(docs['ActorData'],'CActorUnit',{'id':id})
        E.SubElement(n,'On',{'Terms':'ActorCreation','Send':'SetScale 0.500000'})
    # Damage effects in standard dependency catalogs (includes ability/splash effects).
    for id,rs in sorted(data['EffectData'].items()):
        tag=rs[-1].tag
        if tag!='CEffectDamage' or all(r.get('default')=='1' for r in rs): continue
        n=E.SubElement(docs['EffectData'],tag,{'id':id})
        for (k,i),v in resolved(data['EffectData'],id).items():
            if k in ('Amount','AttributeBonus'):
                val=mul(v,.1)
                if val is not None: put(n,k,val,i)
        if not len(n): docs['EffectData'].remove(n)
    # Production/research arrays are indexed by command, not by iteration order.
    for id,rs in sorted(data['AbilData'].items()):
        tag=rs[-1].tag
        if tag not in ('CAbilTrain','CAbilBuild','CAbilResearch','CAbilWarpTrain'): continue
        rows={}
        for r in rs:
            for a in r.findall('InfoArray'):
                idx=a.get('index')
                if idx is None: continue
                if a.get('removed')=='1': rows.pop(idx,None); continue
                row=rows.setdefault(idx,{'res':{}})
                if 'Time' in a.attrib: row['time']=a.get('Time')
                time=a.find('Time')
                if time is not None: row['time']=time.get('value')
                for c in a.findall('Resource'):
                    if c.get('index') in ECON: row['res'][c.get('index')]=c.get('value')
        n=E.SubElement(docs['AbilData'],tag,{'id':id})
        for i,row in rows.items():
            p=E.Element('InfoArray',{'index':i})
            if row.get('time') is not None:
                val=mul(row['time'],.5)
                if val is not None: p.set('Time',val)
            for k,v in row['res'].items():
                if v is not None:
                    val=mul(v,.5,True)
                    if val is not None: put(p,'Resource',val,k)
            if len(p) or 'Time' in p.attrib: n.append(p)
        if not len(n): docs['AbilData'].remove(n)
    # Upgrade arrays: only explicit index or unambiguous original array position.
    for id,rs in sorted(data['UpgradeData'].items()):
        if any(r.get('parent') for r in rs) or all(r.get('default')=='1' for r in rs): continue
        entries={}
        for r in rs:
            pos=0
            for c in r.findall('EffectArray'):
                idx=c.get('index')
                if idx is None:
                    if entries and r is not rs[0]:
                        # Later unindexed entries append; do not guess sparse inherited positions.
                        idx=str(max([int(k) for k in entries if k.isdigit()]+[-1])+1)
                    else: idx=str(pos)
                if not idx.isdigit(): continue
                pos=int(idx)+1
                if c.get('removed')=='1': entries.pop(idx,None); continue
                old=entries.setdefault(idx,{})
                old.update(c.attrib)
        n=E.SubElement(docs['UpgradeData'],'CUpgrade',{'id':id})
        for i,a in entries.items():
            ref=a.get('Reference',''); val=a.get('Value'); parts=ref.split(',')
            if val is None or len(parts)!=3: continue
            cat,target,field=parts
            if (cat=='Effect' and (field=='Amount' or field.startswith('AttributeBonus['))) or (cat=='Unit' and target in selected and field in VITAL):
                if a.get('Operation','Add') not in ('Add','Set','Subtract'): continue
                new=mul(val,.1)
                if new is not None: E.SubElement(n,'EffectArray',{'index':i,'Value':new})
        if not len(n): docs['UpgradeData'].remove(n)
    # Gameplay cap and damage clamp; no change to game speed or map layout.
    n=E.SubElement(docs['GameData'],'CGame',{'id':'Dflt'}); put(n,'FoodCappedMax','300'); put(n,'DamageMinimum','0.05')
    out.mkdir(parents=True,exist_ok=True)
    for f,doc in docs.items():
        if not len(doc): continue
        E.indent(doc,space='    '); dest=out/(f+'.xml'); E.ElementTree(doc).write(dest,encoding='utf-8',xml_declaration=True)
        E.parse(dest); counts[f]=len(doc)
    return counts,warnings

def main():
    p=argparse.ArgumentParser(); p.add_argument('--source',type=Path,help='SC2GameData repository directory or zip'); p.add_argument('--out',type=Path,default=ROOT/'MiniCraft_Data'/'Base.SC2Data'/'GameData'); a=p.parse_args()
    if a.out.exists() and any(a.out.iterdir()): raise RuntimeError('Output not empty; choose a new --out or rename old output. No files overwritten.')
    data,layers=fetch_catalogs(a.source); counts,warnings=patch(data,a.out)
    if counts.get('UnitData',0)<30 or counts.get('AbilData',0)<5: raise RuntimeError('Too few entries; inspect input snapshot before using the result.')
    report={'version':'0.1.0-preview','layers':layers,'entries':counts,'warnings':warnings,'status':'XML generated; not validated in Galaxy Editor or SC2'}
    a.out.parent.parent.joinpath('build-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2)); print('Output:',a.out)
if __name__=='__main__':
    try: main()
    except Exception as e: print('BUILD FAILED:',e,file=sys.stderr); sys.exit(1)
