import tempfile, unittest, xml.etree.ElementTree as E
from pathlib import Path
from collections import defaultdict
import build

class Test(unittest.TestCase):
    def test_patch(self):
        d={f:defaultdict(list) for f in build.FILES}
        def add(f,s):
            for n in E.fromstring('<Catalog>'+s+'</Catalog>'): d[f][n.get('id')].append(n)
        add('UnitData','<CUnit id="Marine"><LifeMax value="45"/><Food value="-1"/><CostResource index="Minerals" value="50"/><Radius value="0.375"/></CUnit><CUnit id="Zergling"><Food value="-0.5"/></CUnit><CUnit id="SupplyDepot"><Food value="8"/><Footprint value="Footprint2x2"/></CUnit><CUnit id="Marine"><LifeMax value="50"/></CUnit>')
        add('FootprintData','<CFootprint id="Footprint1x1"/>')
        add('ActorData','<CActorUnit id="Marine" unitName="Marine"/>')
        add('AbilData','<CAbilTrain id="BarracksTrain"><InfoArray index="Train1" Time="25"/></CAbilTrain><CAbilTrain id="BarracksTrain"><InfoArray index="Train1" Time="18"/></CAbilTrain>')
        add('EffectData','<CEffectDamage id="GuassRifle"><Amount value="6"/></CEffectDamage>')
        add('UpgradeData','<CUpgrade id="Weapons1"><EffectArray Reference="Effect,GuassRifle,Amount" Value="1"/></CUpgrade>')
        with tempfile.TemporaryDirectory() as td:
            p=Path(td); counts,warnings=build.patch(d,p)
            u=E.parse(p/'UnitData.xml'); m=u.find("CUnit[@id='Marine']")
            self.assertEqual(m.find('LifeMax').get('value'),'5')
            self.assertEqual(m.find('Food').get('value'),'-0.5')
            self.assertEqual(m.find('CostResource').get('value'),'25')
            self.assertEqual(u.find("CUnit[@id='Zergling']/Food").get('value'),'-0.25')
            self.assertEqual(u.find("CUnit[@id='SupplyDepot']/Footprint").get('value'),'Footprint1x1')
            self.assertIsNone(u.find("CUnit[@id='SupplyDepot']/Food"))
            self.assertEqual(E.parse(p/'AbilData.xml').find('CAbilTrain/InfoArray').get('Time'),'9')
            self.assertEqual(E.parse(p/'EffectData.xml').find('CEffectDamage/Amount').get('value'),'0.6')
            self.assertEqual(E.parse(p/'UpgradeData.xml').find('CUpgrade/EffectArray').get('Value'),'0.1')
            self.assertEqual(E.parse(p/'GameData.xml').find('CGame/FoodCappedMax').get('value'),'300')
    def test_rounding(self): self.assertEqual(build.mul('25',.5,True),'13')
if __name__=='__main__': unittest.main()
