MiniCraft II v0.1.0-preview — 공허의 유산 / 확장 모드 데이터 생성기

이 패키지는 완성된 배틀넷 모드가 아니라 실제 원본 데이터에서 XML 변경분을 생성하는 개발용 초안입니다. 스타2 설치 파일을 수정하지 않습니다.

1. ZIP 압축 해제 후 Build-MiniCraft.bat 실행 (Python 3.9 이상, 인터넷 필요).
   SC2Mapster 공개 데이터 스냅샷을 내려받아 MiniCraft_Data/Base.SC2Data/GameData 에 XML을 생성합니다.
   이미 원본 ZIP 또는 추출 폴더가 있으면: py -3 build.py --source "경로"
2. 갤럭시 에디터: 파일 > 새로 만들기 > 확장 모드(Extension Mod) > 공허의 유산(Void Multi / 멀티플레이어 의존 관계).
3. 빈 모드를 MiniCraft.SC2Mod라는 이름의 StarCraft II Component Folder 형식으로 저장하고 에디터를 닫습니다.
4. 생성된 MiniCraft_Data/Base.SC2Data/GameData 안의 XML 파일을 빈 모드의 Base.SC2Data/GameData로 복사합니다. 기존 커스텀 데이터가 있는 모드에는 덮어쓰지 마세요.
   에디터가 생성한 Base.SC2Data/GameData.xml(카탈로그 목록)이 있다면 기존 내용을 유지하고 필요한 Catalog path="GameData/UnitData.xml" 등 항목이 등록되어 있는지 확인합니다.
5. 에디터로 해당 컴포넌트 모드를 열어 데이터 오류를 확인한 후 일반 SC2Mod 파일로 다른 이름 저장. 확장 모드로 게시하고 사용자 지정 > 섬멸전 > 맵 선택 > 모드로 게임 만들기에서 적용합니다.

변경 정책
- 3종족 주요 섬멸전 유닛/건물 체력, 보호막, 방어력, 일부 재생 수치 10%; 피해량과 속성 추가 피해 10%; 최소 피해 0.05.
- 유닛 모델 상대 크기 50%, 명시된 충돌 반경 50%.
- 인구 소모 50% (0.25 가능), 공급 건물의 제공량 유지; 상한 300 목표.
- 명시된 생산/건설/연구 시간 50%; 유닛 광물/가스와 명시된 생산/연구 비용 50%. 정수 비용은 0.5 이상 올림 (25→13).
- 일반 건물 점유면적 1x1, 2x2, 3x3. 기존 설치 조건과 대응되는 Footprint ID가 있을 때만 교체. 특수 부속건물, 가스 건물, 점막 종양은 점유 면적을 유지합니다.
- 기존 맵, AI, 공격 사거리, 이동 속도, 자원 채취, 에너지는 유지. 캠페인/래더 적용 대상 아님.

미검증 / 후속 작업
- 실제 에디터 및 게임 실행 테스트를 하지 않았습니다. 공개 데이터 스냅샷은 설치된 클라이언트와 버전이 다를 수 있습니다.
- 합성 테스트는 코드의 일부 계산/출력만 검증합니다. SC2 카탈로그의 전체 상속/배열 병합 규칙을 완전히 구현하지 않았습니다.
- 변태/변신 시간, 차원관문 충전, 애벌레 생성, 모든 회복 효과/행동, 상속된 공방 업그레이드, 특수 능력 피해와 고정 체력 조건, 추가 줌아웃, AI 인구 상한 별도 로직은 미완료입니다. 소수점 표시 및 게임 내 300 상한을 확인해야 합니다.
- 건물 부속건물 배치/이착륙, 프로토스 소환, 저그 점막 건설, 맵 시작 위치와 AI 빌드 순서가 정상인지 검증 필요.
- 건물 외형과 실제 점유 면적은 별개이며 특수 건물은 충돌/부속건물 위치가 맞지 않을 수 있습니다.
- 생성 결과 build-report.json을 참고하세요. 데이터 ID가 없는 경우 경고하거나 건너뜁니다.

출처: https://github.com/SC2Mapster/SC2GameData
에디터 안내: https://s2editor-guides.readthedocs.io/New_Tutorials/01_Introduction/007_Creating_Mods/
데이터 등록: https://s2editor-guides.readthedocs.io/New_Tutorials/04_Data_Editor/data-spaces/
